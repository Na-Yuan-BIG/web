# Combined GWAS workflow
# Author - Ziyi Xiong
# Version 1.4

# Introduction
# CGWAS combine multiple single trait GWAS results to calculate integrate association result from a set of trait combinations for each SNP specifically. The method increase power detecting SNP having effect (may be weak in GWAS for one trait) on multiple traits and type I error was controlled through a large scale simulation analyses. Significant CGWAS result contains both single trait GWAS hits and multiple traits combined GWAS hits after multiple test.

# Input
# N group standard PLINK output (same rows, same SNPs, same order, no covariant rows, no NA rows)
# package (data.table)
# package (MASS)

# Output
# Correction : Uncorrected & Corrected simulation FDR & qqplots
# nSatasCor.csv : Correlation matrix of n trait Stats
# All.corrcp : Original GWAS P Ordered n trait corrected combined GWAS P 
# All.corrsortsp : Original GWAS P Ordered n trait corrected original GWAS P
# All.labsp : Original GWAS P Ordered n trait labels
# All.sp : n trait uncorrected original GWAS P
# AllHits.csv : Final result table
# CgwasRawSuggHits.csv : All SNP hits with corrected combined GWAS P value lower than suggestive threshold
# GwasDataCheck.txt : Original GWAS lambda
# GwasRawSuggHits.csv : All SNP hits with corrected original GWAS P value lower than suggestive threshold
# HJ_bar.txt : Data for Haojie Lu's web page bar plots display
# HJ_man.txt : Data for Haojie Lu's web page Manhattan plots display
# man.jpg : Final result figure
# Min.corrcp : Minimum of n trait corrected combined GWAS P
# Min.corrsp : Minimum of n trait corrected original GWAS P
# qq.jpg : Final result figure
# SNPindex : SNP info
# TopSNP.csv : Final result table

# For column explanation in TopSNP.csv :
# CHR/BP/SNP : GWAS summary data
# SNPid : Index of the SNP in all SNP 
# Loci : Genetic region divided each 500kbp up or downstream the top SNP
# Sp_or_Cp : Which type of analysis the SNP's P value is top in of the located region
# 	S means: Single trait GWAS
# 	C means: Combined GWAS
# 	SC means: Both top in one SNP
# MinCorrSp: Min corrected original GWAS P value of N trait GWAS
# MinCorrCp: Min corrected combined GWAS P value of N trait CGWAS
# MinSpTrait: Which trait the SNP is the most significantly associated with
# SpSigType: 0/1/2; Intensity of corrected original GWAS P significance. 
# 	0 means: none of N p<sug.line
# 	1 means: At least one p<sug.line & none of N p<geno.line
# 	2 means: At least one p<geno.line
# CpSigType: Definition is the same as SpSigType, but for CGWAS P
# SpSigNum: For each SNP, which number of P from corrected original GWAS<0.05 (hypothesis: the SNP is True Positive in current sample)
# MinCpNum: Which number of trait combination the SNP is the most significantly associated with
# Rank N: Order N trait name from GWAS
# Corrsp N: Order N trait corrected original GWAS p
# Corrcp N: Order N trait corrected combined CGWAS p

# How to begin :
# Set property of function script
# Unload function script
# Set CGWAS work path
# locate in path of function script and run R
# In turn run function below

# Environment set (Only run once at start of project)
system(paste0("mkdir Tempdata"))
system(paste0("mkdir Tempdata/Coldata"))
system(paste0("mkdir Tempdata/Rowdata"))
system(paste0("mkdir Tempdata/Simudata"))
system(paste0("mkdir Tempdata/Simudata/Allp"))
system(paste0("mkdir Tempdata/Simudata/Minp"))
system(paste0("mkdir Result"))
system(paste0("mkdir Result/Correction"))

# Load function
source("V1.4_CGWASfunction.r")

# Data preparation
step1()

# simulation
step2()

# Simulation FDR (note: TaskAmount>TraitAmount)
step3(taskvector=1:length(Traitname))

# Actual data CGWAS
step4()

# Optimization inflation correction & Raw hits
step5()

# Merged Manhattan & QQ plots
step6(m_wid=3500,m_hei=3500,sing_col=c('chartreuse2','chartreuse4'),comb_col=c('darkgoldenrod2','darkgoldenrod4'),speeduppoints=T,q_wid=3500,q_hei=2400)

# Suggestive & Genomewide & Multiple test correction & TopSNPs
step7()
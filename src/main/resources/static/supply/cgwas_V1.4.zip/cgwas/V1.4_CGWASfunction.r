# Initialization setting

# Version
ve <- "1.4"

# CGWAS workpath
CGPath <- "/data/xiongzy/jingxx/1.4CGWAS/"

# Single trait association data path
ST_Datapath <- "/data/jingxx/facial.aging/gwas.mul/"

# Rscript path
Rscript_path <- "/bin/Rscript"

# FunctionScript path
function_path <- "/data/xiongzy/jingxx/1.4CGWAS/"

# Single trait association file name
ST_Filename <- c("AK.assoc.linear","MPA.assoc.linear","PA.assoc.linear","PS.assoc.linear","TE.assoc.linear","w.assoc.linear")

# Trait name (same order as above)
Traitname <- c("AK","MPA","PA","PS","TE","w")

# Simulate corrected inflation factor
Correctlambda <- TRUE

# Corrected GIF (same order as above)
Clv <- rep(1,length(Traitname))

# Column number of SNP index (CHR & BP & SNP)
IndexCN <- c(1,3,2)

# Column number of association data (BETA & P)
DataCN <- c(7,12)

# Fixed decimal digits
Fdd <- FALSE

# BETA decimal digits
Bdd <- 4

# Parallel task number
Sepblock <- 50

# Simulation times
SimuNum <- 2500

# Genome-wide threshold
Gt <- 5e-8

# Suggestive threshold
St <- 1e-6

# Display threshold (Haojie Lu's web page display)
Ht <- 1e-3

# Total SNP amount
Rsnpnum <- 6886438

# HPC/Server
HPC <- FALSE



#----------Function----------#

library("MASS")
library("data.table")

mkdf <- function(cm,n){
  df <- mvrnorm(n,mu=rep(0,ncol(cm)),Sigma=cm)
  return(df)
}

preCorrection <- function(){
	qv <<- c(1:ceiling(Rsnpnum*0.001),seq(ceiling(Rsnpnum*0.001)+1,ceiling(Rsnpnum*0.01),round(Rsnpnum*0.000005)),seq(ceiling(Rsnpnum*0.01)+1,ceiling(Rsnpnum*0.9999)-1,round(Rsnpnum*0.0005)),ceiling(Rsnpnum*0.9999):Rsnpnum)
}

corterm3all <- function(p,b,fc1,fc2,fc3,fc4){
  temv <- which(b<0)
  fc1[temv,] <- -fc1[temv,]
  fc1[,temv] <- -fc1[,temv]
  fc3[temv,] <- -fc3[temv,]
  fc3[,temv] <- -fc3[,temv]
  corm <- 3.2630398097*fc1 + 0.7095678755*fc2 + 0.0268257772*fc3 + 0.0005732151*fc4
  stepw <- order(p)  
  p <- p[stepw]
  corm <- corm[stepw,stepw]
  stat <- -2*log(p)
  curcov <- rep(0,ncol(corm))
  for(nn in 2:ncol(corm)){
    stat[nn] <- stat[nn]+stat[nn-1]
    curcov[nn] <- curcov[nn-1]+sum(corm[1:(nn-1),nn])
  }
  V <- 2*curcov + 2*E
  cp <- pchisq(2*E*stat/V,2*E^2/V,lower.tail=F)
  return(cp)
}

simuqqplot <- function(pm,title,simunum,spn,Esp){
	e <- -quantile(log10(ppoints(Esp)),(qv-1)/(spn-1))
	hpv <- apply(pm,2,function(a){return(quantile(a,0.05))})
	eh <- -log10(hpv)
	em <- -log10(apply(pm,2,function(a){return(quantile(a,0.5))}))
	el <- -log10(apply(pm,2,function(a){return(quantile(a,0.95))}))
	ttp <- -log10(hpv[1])
	plot(c(0,max(e)), c(0,ttp), type="n" ,xlab = "Expected -LogP", ylab = "Observed -LogP", main = title)
	polygon(c(e,e[length(e):1]),c(el,eh[length(e):1]),border="black",col="grey80")
	points(e, em, pch=20)
	text(0.5,max(ttp),expression(italic(P)[Sim]),adj=1)
	text(0.5,max(ttp)*0.95,expression(italic(P)[Set]),adj=1)
	text(0.5,max(ttp)*0.9,expression(italic(FDR)[Set]),adj=1)
	text(0.5,max(ttp),paste0(" = ",signif(hpv[1],3)),adj=0)
	text(0.5,max(ttp)*0.95,paste0(" = ",signif(0.05/Esp,3)),adj=0)
	text(0.5,max(ttp)*0.9,paste0(" = ",signif(mean(order(abs(sort(pm[,1])-Gt),decreasing=F)[1:2])/simunum,3)),adj=0)
	abline(c(0,1),col="red")
}

simutime <- function(pm,simunum,Esp,title){
	pv95 <- c()
	for(i in 20:simunum){
		pv95 <- c(pv95,mean(order(abs(sort(pm[1:i,1])-0.05/Esp),decreasing=F)[1:2])/i)
	}
	plot(c(20,simunum), c(min(min(pv95),0.05),max(max(pv95),0.05)), type="n" ,xlab = "Simu Time", ylab = "FDR", main = title)
	lines(c(20:simunum),pv95,lwd=2)
	abline(c(0.05,0),col="red")
}

manhattan <- function(indscp,spt.col=c('gray10','gray50'),cpt.col=c('gray10','gray50'),spt.bg=c('gray10','gray50'),cpt.bg=c('gray10','gray50'),spt.cex=0.7,cpt.cex=0.7,pch=21,cex.axis=1.1,suggestiveline.col='blue',suggestiveline.lwd=1.5,suggestiveline.lty=1,genomewideline.col='red',genomewideline.lwd=1.5,genomewideline.lty=1){

    d=indscp
    colnames(d)=c("CHR","BP","SNP","SP","CP")
    d$pos=NA

	ytop=max(ceiling(max(d$CP)),ceiling(max(d$SP)))
	if(ytop>10){
		d$CP[d$CP>10]=d$CP[d$CP>10]/5+8
		d$SP[d$SP>10]=d$SP[d$SP>10]/5+8
		if(ytop>50){
			d$CP[d$CP>18]=d$CP[d$CP>18]/5+14.4
			d$SP[d$SP>18]=d$SP[d$SP>18]/5+14.4
			if(ytop>200){
				d$CP[d$CP>24]=24.4
				d$SP[d$SP>24]=24.4
			}
		}
	}
	ymax=ceiling(max(d$CP))
	ymin=-ceiling(max(d$SP))

	d$index=NA
	ind=0
	for(i in unique(d$CHR)){
		ind = ind + 1
		d[d$CHR==i,]$index = ind
	}
	
    nchr=length(unique(d$CHR))
    if (nchr==1){
        d$pos=d$BP
        ticks=floor(length(d$pos))/2+1
        xlabel=paste('Chromosome',unique(d$CHR),'position')
        labs=ticks
    } else{
    	ticks=rep(NA,length(unique(d$CHR))+1)
    	ticks[1]=0
        for(i in 1:max(d$index)){
          	d[d$index==i,]$pos=(d[d$index==i,]$BP-d[d$index==i,]$BP[1])+1+ticks[i]
    		ticks[i+1]=max(d[d$index==i,]$pos)
    	}
    	xlabel = 'Chromosome'
    	labs = unique(d$CHR)
	}
    
    xmax=max(d$pos)*1.03
    xmin=max(d$pos)*-0.03
    plot(0,col=F,xaxt='n',yaxt='n',bty='n',xaxs='i',xlim=c(xmin,xmax),ylim=c(ymin,ymax),xlab="",ylab=expression(-log[10](italic(p))),las=1,cex.axis=cex.axis)
	
	blank=rep('',length(labs))
	lowerlabs=rep('',length(labs))
	upperlabs=rep('',length(labs))
	
	for (i in 1:length(labs)){
		if (i %% 2 == 0){
			lowerlabs[i] = labs[i]
		} else{
			upperlabs[i] = labs[i]
		}
	}
	
	newtick <- c()
	for(i in 1:(length(ticks)-1)){
		newtick <- c(newtick,(ticks[i]+ticks[i+1])/2)
	}

	l=c(-seq(2,24,2)[floor(-ymin/2):1],0,seq(2,24,2)[1:floor(ymax/2)])
	ll=c(c(2,4,6,8,10,20,30,40,50,100,150,200)[floor(-ymin/2):1],0,c(2,4,6,8,10,20,30,40,50,100,150,200)[1:floor(ymax/2)])
	axis(2,las=1,at=l,labels=as.character(ll),lwd=0,lwd.ticks=1,cex.axis=cex.axis)

	d$SP[which(d$SP==0)] <- NA
	d$CP[which(d$CP==0)] <- NA
    pt.col = rep(cpt.col,max(d$CHR))[1:max(d$CHR)]
	pt.bg = rep(cpt.bg,max(d$CHR))[1:max(d$CHR)]

    icol=1
    for (i in unique(d$CHR)) {
        with(d[d$CHR==i, ],points(pos, CP, col=pt.col[icol],bg=pt.bg[icol],cex=cpt.cex,pch=pch))
        icol=icol+1
    }
    
    pt.col = rep(spt.col,max(d$CHR))[1:max(d$CHR)]
	pt.bg = rep(spt.bg,max(d$CHR))[1:max(d$CHR)]

    icol=1
    for (i in unique(d$CHR)) {
        with(d[d$CHR==i, ],points(pos, -SP, col=pt.col[icol],bg=pt.bg[icol],cex=spt.cex,pch=pch))
        icol=icol+1
    }

	text(newtick,-0.25,lowerlabs,cex=1.1)
	text(newtick,0.25,upperlabs,cex=1.1)

    abline(h=-log10(St), col=suggestiveline.col[1],lwd=suggestiveline.lwd,lty=suggestiveline.lty)
    abline(h=log10(St), col=suggestiveline.col[1],lwd=suggestiveline.lwd,lty=suggestiveline.lty)
    abline(h=-log10(Gt), col=genomewideline.col[1],lwd=genomewideline.lwd,lty=genomewideline.lty)
    abline(h=log10(Gt), col=genomewideline.col[1],lwd=genomewideline.lwd,lty=genomewideline.lty)

	box()
}

qq <- function(datasm,datacm,minm,e,sgif,cgif,twoc=c('gray10','gray50')){

	myc <- c(colorRampPalette(c("navy","blue","cyan","chartreuse","yellow","orange","Red","darkred"))(1000))

	axis2 <- function(ym){
		l=c(0,seq(2,24,2)[1:floor(ym/2)])
		ll=c(0,c(2,4,6,8,10,20,30,40,50,100,150,200)[1:floor(ym/2)])
		axis(2,las=1,at=l,labels=as.character(ll),lwd=0,lwd.ticks=1,cex.axis=0.95)
	}

	ytop <- max(datasm[1,])
	if(ytop>10){
		datasm[datasm>10]=datasm[datasm>10]/5+8
		if(ytop>50){
			datasm[datasm>18]=datasm[datasm>18]/5+14.4
			if(ytop>200){
				datasm[datasm>24]=24.4
			}
		}
	}

	xmax <- max(e)*1.03
	xmin <- max(e)*-0.03
	ymax <- max(datasm[1,])*1.03
	ymin <- -ymax*0.03
	plot(0,xlab=expression(Expected~~-log[10](italic(p))),ylab=expression(Observed~~-log[10](italic(p))),col=F,las=1,xaxt='n',yaxt='n',xlim=c(xmin,xmax),ylim=c(ymin,ymax),bty='n',xaxs='i',yaxs='i',cex.axis=0.95)
	axis(side=1,labels=seq(0,xmax,1),at=seq(0,xmax,1),cex.axis=0.95,lwd=0,lwd.ticks=1)
	axis2(ymax)

	for(i in 1:length(Traitname)){
		points(e,datasm[,i],pch=20,cex=0.9,col=myc[round(i*1000/(length(Traitname)+1))])
		print(paste0(i," GWAS QQ Plots Completed"))
	}
	abline(0,1,col="black",lwd=1.5,lty=1)
	box()
	print(paste0("Overlap GWAS QQ Plots Completed"))


	xmax <- 3*1.03
	xmin <- 3*-0.03
	ymax <- 3*1.03
	ymin <- -ymax*0.03
	plot(0,xlab=expression(Expected~~-log[10](italic(p))),ylab=expression(Observed~~-log[10](italic(p))),col=F,las=1,xaxt='n',yaxt='n',xlim=c(xmin,xmax),ylim=c(ymin,ymax),bty='n',xaxs='i',yaxs='i',cex.axis=0.95)
	axis(side=1,labels=seq(0,xmax,1),at=seq(0,xmax,1),cex.axis=0.95,lwd=0,lwd.ticks=1)
	axis(side=2,las=1,labels=seq(0,ymax,1),at=seq(0,ymax,1),cex.axis=0.95,lwd=0,lwd.ticks=1)
	for(i in 1:length(Traitname)){
		cpind <- datasm[,i]<ymax
		points(e[cpind],datasm[cpind,i],pch=20,cex=0.9,col=myc[round(i*1000/(length(Traitname)+1))])
		print(paste0(i," Local GWAS QQ Plots Completed"))
	}
	abline(0,1,col="black",lwd=1.5,lty=1)
	box()
	print(paste0("Local GWAS QQ Plots Completed"))


	ytop <- max(minm)
	if(ytop>10){
		minm[minm>10]=minm[minm>10]/5+8
		if(ytop>50){
			minm[minm>18]=minm[minm>18]/5+14.4
			if(ytop>200){
				minm[minm>24]=24.4
			}
		}
	}

	xmax <- max(e)*1.03
	xmin <- max(e)*-0.03
	ymax <- max(minm)*1.03
	ymin <- -ymax*0.03
	plot(0,xlab=expression(Expected~~-log[10](italic(p))),ylab=expression(Observed~~-log[10](italic(p))),col=F,las=1,xaxt='n',yaxt='n',xlim=c(xmin,xmax),ylim=c(ymin,ymax),bty='n',xaxs='i',yaxs='i',cex.axis=0.95)
	axis(side=1,labels=seq(0,xmax,1),at=seq(0,xmax,1),cex.axis=0.95,lwd=0,lwd.ticks=1)
	axis2(ymax)

	points(e,minm[,1],pch=20,cex=0.9,col=twoc[1])
	points(e,minm[,2],pch=20,cex=0.9,col=twoc[2])
	abline(0,1,col="black",lwd=1.5,lty=1)
	box()
	print(paste0("Minp QQ Plots Completed"))


	ytop <- max(datacm[1,])
	if(ytop>10){
		datacm[datacm>10]=datacm[datacm>10]/5+8
		if(ytop>50){
			datacm[datacm>18]=datacm[datacm>18]/5+14.4
			if(ytop>200){
				datacm[datacm>24]=24.4
			}
		}
	}

	xmax <- max(e)*1.03
	xmin <- max(e)*-0.03
	ymax <- max(datacm[1,])*1.03
	ymin <- -ymax*0.03
	plot(0,xlab=expression(Expected~~-log[10](italic(p))),ylab=expression(Observed~~-log[10](italic(p))),col=F,las=1,xaxt='n',yaxt='n',xlim=c(xmin,xmax),ylim=c(ymin,ymax),bty='n',xaxs='i',yaxs='i',cex.axis=0.95)
	axis(side=1,labels=seq(0,xmax,1),at=seq(0,xmax,1),cex.axis=0.95,lwd=0,lwd.ticks=1)
	axis2(ymax)

	for(i in 1:length(Traitname)){
		points(e,datacm[,i],pch=20,cex=0.9,col=myc[round(i*1000/(length(Traitname)+1))])
		print(paste0(i," CGWAS QQ Plots Completed"))
	}
	abline(0,1,col="black",lwd=1.5,lty=1)
	box()
	print(paste0("Overlap CGWAS QQ Plots Completed"))


	xmax <- 3*1.03
	xmin <- 3*-0.03
	ymax <- 3*1.03
	ymin <- -ymax*0.03
	plot(0,xlab=expression(Expected~~-log[10](italic(p))),ylab=expression(Observed~~-log[10](italic(p))),col=F,las=1,xaxt='n',yaxt='n',xlim=c(xmin,xmax),ylim=c(ymin,ymax),bty='n',xaxs='i',yaxs='i',cex.axis=0.95)
	axis(side=1,labels=seq(0,xmax,1),at=seq(0,xmax,1),cex.axis=0.95,lwd=0,lwd.ticks=1)
	axis(side=2,las=1,labels=seq(0,ymax,1),at=seq(0,ymax,1),cex.axis=0.95,lwd=0,lwd.ticks=1)
	for(i in 1:length(Traitname)){
		cpind <- datacm[,i]<ymax
		points(e[cpind],datacm[cpind,i],pch=20,cex=0.9,col=myc[round(i*1000/(length(Traitname)+1))])
		print(paste0(i," Local CGWAS QQ Plots Completed"))
	}
	abline(0,1,col="black",lwd=1.5,lty=1)
	box()
	print(paste0("Local CGWAS QQ Plots Completed"))


	xmax <- length(Traitname)*1.03
	xmin <- length(Traitname)*-0.03+1
	ymax <- max(max(sgif),max(cgif),1)+(max(max(sgif),max(cgif),1)-min(min(sgif),min(cgif),1))*0.03
	ymin <- min(min(sgif),min(cgif),1)-(max(max(sgif),max(cgif),1)-min(min(sgif),min(cgif),1))*0.03
	plot(0,xlab="Combined Trait Number",ylab="Inflation Factor",col=F,las=1,xaxt='n',,yaxt='n',xlim=c(xmin,xmax),ylim=c(ymin,ymax),bty='n',xaxs='i',yaxs='i',cex.axis=0.95)
	axis(side=1,cex.axis=0.95,lwd=0,lwd.ticks=1)
	axis(side=2,las=1,cex.axis=0.95,lwd=0,lwd.ticks=1)

	for(ii in seq(0.05,0.45,1/150)){
		rect(xleft=xmin,ybottom=quantile(sgif,1-ii),xright=xmax,ytop=quantile(sgif,ii),col=paste0("grey",97.5-150*ii),border=paste0("grey",97.5-150*ii))
	}
	abline(c(quantile(sgif,1),0),lty=3,lwd=1.5)
	abline(c(quantile(sgif,0.95),0),lty=2,lwd=1.5)
	abline(c(quantile(sgif,0.5),0),lwd=1.5)
	abline(c(quantile(sgif,0.05),0),lty=2,lwd=1.5)
	abline(c(quantile(sgif,0),0),lty=3,lwd=1.5)
	for(ii in 1:(length(Traitname)-1)){
		lines(c(ii,ii+1),c(cgif[ii],cgif[ii+1]),col=myc[round(ii*1000/length(Traitname))],lwd=1.5)
	}
	points(1:length(Traitname),cgif,col=myc[round((1:length(Traitname))*1000/(length(Traitname)+1))],bg=myc[round((1:length(Traitname))*1000/(length(Traitname)+1))],pch=23,cex=1.5)
	box()

	print(paste0("Lambda Plots Completed"))
}

step1 <- function(){
	setwd(paste0(CGPath,"Result/"))
	system(paste0("cat ",ST_Datapath,ST_Filename[1]," | awk '{print $",IndexCN[1],",$",IndexCN[2],",$",IndexCN[3],"}' > SnpIndex"))
	print("SnpIndex Completed")

	setwd(paste0(CGPath,"Tempdata/Coldata/"))
	for(i in 1:length(Traitname)){
		system(paste0("cat ",ST_Datapath,ST_Filename[i]," | awk '{print $",DataCN[1],",$",DataCN[2],"}' > ",i,".bp"))
		print(paste0(i," Trait GWAS Data Extracted"))
	}
	tm <- matrix(0,Rsnpnum,length(Traitname))
	for(i in 1:length(Traitname)){
		bpm <- read.table(paste0(i,".bp"),header=T,colClasses="character",stringsAsFactors=F)
		if(Fdd){
			sig <- 2*as.numeric(nchar(bpm[,1])==(Bdd+2))-1
			tm[,i] <- -qnorm(as.numeric(bpm[,2])/2)*sig
		} else{
			tm[,i] <- -qnorm(as.numeric(bpm[,2])/2)*abs(as.numeric(bpm[,1]))/as.numeric(bpm[,1])
		}
		print(paste0(i," Trait Statistics Generated"))
	}

	setwd(paste0(CGPath,"Result/"))
	lv <- c()
	for(i in 1:length(Traitname)){
		lv <- c(lv,quantile(abs(tm[,i]),0.5)/qnorm(0.75))
		print(paste0(Traitname[i]," lambda: ",round(lv[i],4)))
		if(Correctlambda){
			tm[,i] <- tm[,i]/lv[i]*Clv[i]
			print(paste0(Traitname[i]," corrected lambda: ",round(quantile(abs(tm[,i]),0.5)/qnorm(0.75),4)))
		}
	}
	print(paste0("Average lambda: ",round(mean(lv),4)))

	write.table(cbind(Traitname,lv),"GwasDataCheck.txt",row.names=F,col.names=F,quote=F)

	print(paste0("Calculate Correlation Matrix.."))
	ctm <- cor(tm)
	colnames(ctm) <- Traitname
	write.csv(ctm,paste0(length(Traitname),"StatsCor.csv"),row.names=F,quote=F)
	print(paste0("Correlation Matrix Completed"))

	setwd(paste0(CGPath,"Tempdata/Rowdata/"))
	for(i in 1:(Sepblock-1)){
		fwrite(as.data.frame(tm[(round(Rsnpnum/Sepblock)*(i-1)+1):(round(Rsnpnum/Sepblock)*i),]),paste0(i,".s"),row.names=F,sep=" ")
		print(paste0(i," Data Block Saved"))
	}
	fwrite(as.data.frame(tm[(round(Rsnpnum/Sepblock)*(Sepblock-1)+1):nrow(tm),]),paste0(Sepblock,".s"),row.names=F,sep=" ")
	print(paste0("All Data Block Saved"))
	print(paste0("Step1 Completed"))
}

step2 <- function(){
	setwd(paste0(CGPath,"Tempdata/Simudata/Allp/"))
	for(n in 1:Sepblock){
		sink(paste0("Simulation",n,".r"))
		writeLines(paste0("#! ",Rscript_path))
		writeLines(paste0("spnum <- ",Sepblock))
		writeLines(paste0("pertime <- ",SimuNum))
		writeLines(paste0("Esnp <- ",0.05/Gt))
		writeLines(paste0("Rsnpnum <- ",Rsnpnum))
		writeLines(paste0("Simulambda <- ",Correctlambda))
		writeLines(paste0("lambda <- c(",paste0(Clv,collapse=","),")"))
		writeLines(paste0("ocorm <- as.matrix(read.csv(\"",CGPath,"Result/",length(Traitname),"StatsCor.csv\",header=T))"))
		writeLines("E <- 2*(1:ncol(ocorm))")
		writeLines(paste0("source(\"",function_path,"V",ve,"_CGWASfunction.r\")"))
		writeLines("preCorrection()")

		writeLines(paste0("setwd(\"",CGPath,"Tempdata/Simudata/Allp/\")"))
		writeLines("fminm <- matrix(0,ncol=ncol(ocorm),nrow=(pertime/spnum)*length(qv))")
		writeLines("ocorm2 <- ocorm^2")
		writeLines("ocorm3 <- ocorm^3")
		writeLines("ocorm4 <- ocorm^4")
		writeLines("for(iii in 1:(pertime/spnum)){")
			writeLines("resm <- matrix(0,ncol=ncol(ocorm),nrow=Esnp)")
			writeLines("fillind <- (length(qv)*(iii-1)+1):(length(qv)*iii)")
			writeLines("dm <- signif(mkdf(ocorm,Esnp),10)")
			writeLines("if(Simulambda){")
				writeLines("dm <- t(t(dm)*lambda)")
			writeLines("}")
			writeLines("pm <- pnorm(-abs(dm))*2")

			writeLines("for(i in 1:Esnp){")
				writeLines("resm[i,] <- corterm3all(pm[i,],dm[i,],ocorm,ocorm2,ocorm3,ocorm4)")
			writeLines("}")

			writeLines("rm(dm)")
			writeLines("rm(pm)")
			writeLines("fminm[fillind,] <- 10^(apply(log10(resm),2,quantile,probs=((qv-1)/(Rsnpnum-1))))")
			writeLines("rm(resm)")
			
			writeLines("if((iii%%(pertime/spnum*0.1))==0){")
				writeLines(paste0("write.table(NA,paste0(\"f\",",n,",\"_\",iii*spnum/pertime*100,\"%\"))"))
			writeLines("}")
		writeLines("}")

		writeLines(paste0("system(\"rm f",n,"_*\")"))
		writeLines("for(iii in 1:ncol(fminm)){")
			writeLines(paste0("write.table(t(matrix(fminm[,iii],nrow=length(qv))),paste0(\"qutm\",",n,",\"_\",iii),row.names=F,col.names=F,quote=F)"))
		writeLines("}")
		sink()
	}
	if(HPC){
		for(n in seq(1,Sepblock,2)){
			system(paste0("chmod +x Simulation",n,".r"))
			system(paste0("csub -q bioque -N xzy",n," -p 1 -m 3gb -w 80:00:00 -c \"",CGPath,"Tempdata/Simudata/Allp/Simulation",n,".r\""))
		}
		for(n in seq(2,Sepblock,2)){
			system(paste0("chmod +x Simulation",n,".r"))
			system(paste0("csub -q geneque -N xzy",n," -p 1 -m 3gb -w 80:00:00 -c \"",CGPath,"Tempdata/Simudata/Allp/Simulation",n,".r\""))
		}
	} else {
		for(n in 1:Sepblock){
			system(paste0("chmod +x Simulation",n,".r"))
			system(paste0("nohup ./Simulation",n,".r &"))
		}
		for(n in 1:Sepblock){
			system(paste0("rm Simulation",n,".r"))
		}
	}
	print(paste0("Step2 Proceeding"))
	print(paste0("Proceed Further After All Parallel Task Finished"))
}

step3 <- function(taskvector=1:length(Traitname)){
	setwd(paste0(CGPath,"Tempdata/Simudata/Allp/"))
	if(HPC){
		system("rm x*")
		for(n in 1:Sepblock){
			system(paste0("rm Simulation",n,".r"))
		}
	}

	preCorrection()
	write.table(as.data.frame(10^(quantile(log10(qbeta(0.05,1:(0.05/Gt),(0.05/Gt):1)),(qv-1)/(Rsnpnum-1)))),paste0("../Minp/",length(Traitname)+1),row.names=F,col.names=F,quote=F)

	for(n in taskvector){
		sink(paste0("Correction",n,".r"))
		writeLines(paste0("#! ",Rscript_path))
		writeLines(paste0("Esnp <- ",0.05/Gt))
		writeLines(paste0("Rsnpnum <- ",Rsnpnum))
		writeLines(paste0("SimuNum <- ",SimuNum))
		writeLines(paste0("source(\"",function_path,"V",ve,"_CGWASfunction.r\")"))
		writeLines("preCorrection()")
		writeLines(paste0("spnum <- ",Sepblock))
		writeLines(paste0("Traitname <- c(",paste0("\"",Traitname,"\"",collapse=","),")"))
		writeLines(paste0("n <- ",n))
		writeLines(paste0("setwd(\"",CGPath,"Tempdata/Simudata/Allp/\")"))

		writeLines("system(paste0(\"cat \",paste0(\"qutm\",1:spnum,\"_\",n,collapse=\" \"),\" > qm\",SimuNum,\"_\",n))")
		writeLines("for(i in 1:spnum){")
		writeLines("system(paste0(\"rm qutm\",i,\"_\",n))")
		writeLines("}")
		writeLines("qm <- as.matrix(fread(paste0(\"qm\",SimuNum,\"_\",n),header=F))")

		writeLines("basecf <- as.numeric(read.table(paste0(\"../Minp/\",length(Traitname)+1),header=F,stringsAsFactors=F)[,1])")
		writeLines("curcf <- apply(qm,2,quantile,probs=0.05)")
		writeLines("write.table(as.data.frame(curcf),paste0(\"../Minp/\",n),row.names=F,col.names=F,quote=F)")

		writeLines(paste0("setwd(\"",CGPath,"Result/Correction/\")"))
		writeLines("jpeg(paste0(n,\".jpg\"), width=3600, height=1350, res=200)")
		writeLines("par(mfrow=c(1,3))")
		writeLines("simuqqplot(qm,\"Original\",SimuNum,Rsnpnum,Esnp)")
		writeLines("simuqqplot(t(t(qm)*basecf/curcf),\"Corrected\",SimuNum,Rsnpnum,Esnp)")
		writeLines("simutime(t(t(qm)*basecf/curcf),SimuNum,Esnp,\"Simulate FDR\")")
		writeLines("dev.off()")

		sink()
	}
	if(HPC){
		for(n in seq(min(taskvector),max(taskvector),2)){
			system(paste0("chmod +x Correction",n,".r"))
			system(paste0("csub -q bioque -N xzy",n," -p 1 -m 2gb -w 80:00:00 -c \"",CGPath,"Tempdata/Simudata/Allp/Correction",n,".r\""))
		}
		for(n in seq(min(taskvector)+1,max(taskvector),2)){
			system(paste0("chmod +x Correction",n,".r"))
			system(paste0("csub -q geneque -N xzy",n," -p 1 -m 2gb -w 80:00:00 -c \"",CGPath,"Tempdata/Simudata/Allp/Correction",n,".r\""))
		}
	} else {
		for(n in taskvector){
			system(paste0("chmod +x Correction",n,".r"))
			system(paste0("nohup ./Correction",n,".r &"))
		}
		for(n in taskvector){
			system(paste0("rm Correction",n,".r"))
		}
	}
	print(paste0("Step3 Proceeding"))
	print(paste0("Proceed Further After All Parallel Task Finished"))
}

step4 <- function(){
	if(HPC){
		setwd(paste0(CGPath,"Tempdata/Simudata/Allp/"))
		system("rm x*")
		system("rm Correction*")
	}

	setwd(paste0(CGPath,"Tempdata/Rowdata/"))
	for(n in 1:Sepblock){
		sink(paste0("Cp",n,".r"))
		writeLines(paste0("#! ",Rscript_path))
		writeLines(paste0("source(\"",function_path,"V",ve,"_CGWASfunction.r\")"))
		writeLines(paste0("Traitname <- c(",paste0("\"",Traitname,"\"",collapse=","),")"))
		writeLines(paste0("ocorm <- as.matrix(read.csv(paste0(\"",CGPath,"Result/",length(Traitname),"StatsCor.csv\"),header=T))"))
		
		writeLines(paste0("setwd(\"",CGPath,"Tempdata/Rowdata/\")"))
		writeLines(paste0("tm <- as.matrix(fread(paste0(",n,",\".s\"),header=T))"))
		writeLines("pm <- pnorm(-abs(tm))*2")
		writeLines("E <- 2*(1:ncol(ocorm))")
		writeLines("resm <- matrix(0,ncol=ncol(ocorm),nrow(pm))")
		writeLines("labm <- matrix(0,ncol=ncol(ocorm),nrow(pm))")
		writeLines("ordm <- matrix(0,ncol=ncol(ocorm),nrow(pm))")
		writeLines("ocorm2 <- ocorm^2")
		writeLines("ocorm3 <- ocorm^3")
		writeLines("ocorm4 <- ocorm^4")
		writeLines("for(i in 1:nrow(pm)){")
			writeLines("stepw <- order(pm[i,])")
			writeLines("resm[i,] <- corterm3all(pm[i,],tm[i,],ocorm,ocorm2,ocorm3,ocorm4)")
			writeLines("labm[i,] <- c(Traitname[stepw])")
			writeLines("ordm[i,] <- signif(pm[i,stepw],8)")
		writeLines("}")

		writeLines(paste0("setwd(\"",CGPath,"Result/\")"))
		writeLines(paste0("write.table(as.data.frame(signif(resm,8)),paste0(",n,",\".res\"),row.names=F,col.names=F,quote=F)"))
		writeLines(paste0("write.table(as.data.frame(labm),paste0(",n,",\".lo\"),row.names=F,col.names=F,quote=F)"))
		writeLines(paste0("write.table(as.data.frame(ordm),paste0(",n,",\".o\"),row.names=F,col.names=F,quote=F)"))
		writeLines(paste0("write.table(as.data.frame(signif(pm,4)),paste0(",n,",\".ro\"),row.names=F,col.names=F,quote=F)"))
		sink()
	}
	if(HPC){
		for(n in seq(1,Sepblock,2)){
			system(paste0("chmod +x Cp",n,".r"))
			system(paste0("csub -q bioque -N xzy",n," -p 1 -m 1gb -w 80:00:00 -c \"",CGPath,"Tempdata/Rowdata/Cp",n,".r\""))
		}
		for(n in seq(2,Sepblock,2)){
			system(paste0("chmod +x Cp",n,".r"))
			system(paste0("csub -q geneque -N xzy",n," -p 1 -m 1gb -w 80:00:00 -c \"",CGPath,"Tempdata/Rowdata/Cp",n,".r\""))
		}
	} else {
		for(n in 1:Sepblock){
			system(paste0("chmod +x Cp",n,".r"))
			system(paste0("nohup ./Cp",n,".r &"))
		}
		for(n in 1:Sepblock){
			system(paste0("rm Cp",n,".r"))
		}
	}
	print(paste0("Step4 Proceeding"))
	print(paste0("Proceed Further After All Parallel Task Finished"))
}

step5 <- function(){
	if(HPC){
		setwd(paste0(CGPath,"Tempdata/Rowdata/"))
		system("rm x*")
		for(n in 1:Sepblock){
			system(paste0("rm Cp",n,".r"))
		}
	}
	preCorrection()
	
	setwd(paste0(CGPath,"Result/"))
	system(paste0("cat 1.o > All.sortsp"))
	system(paste0("rm 1.o"))
	system(paste0("cat 1.lo > All.labsp"))
	system(paste0("rm 1.lo"))
	system(paste0("cat 1.ro > All.sp"))
	system(paste0("rm 1.ro"))
	print(paste0("Merge GWAS Data 1"))
	for(i in 2:Sepblock){
		system(paste0("cat ",i,".o >> All.sortsp"))
		system(paste0("rm ",i,".o"))
		system(paste0("cat ",i,".lo >> All.labsp"))
		system(paste0("rm ",i,".lo"))
		system(paste0("cat ",i,".ro >> All.sp"))
		system(paste0("rm ",i,".ro"))
		print(paste0("Merge GWAS Data ",i))
	}

	pm <- matrix(0,ncol=length(Traitname),nrow=Rsnpnum)
	for(i in 1:Sepblock){
		tem <- as.matrix(fread(paste0(i,".res"),header=F))
		pm[(round(Rsnpnum/Sepblock)*(i-1)+1):(round(Rsnpnum/Sepblock)*(i-1)+nrow(tem)),] <- tem
		system(paste0("rm ",i,".res"))
		print(paste0(i," CGWAS Data Extracted"))
	}

	basecf <- as.numeric(read.table(paste0(CGPath,"Tempdata/Simudata/Minp/",length(Traitname)+1),header=F,stringsAsFactors=F)[,1])
	for(i in 1:length(Traitname)){
		curcf <- as.numeric(read.table(paste0(CGPath,"Tempdata/Simudata/Minp/",i),header=F,stringsAsFactors=F)[,1])
		baseper <- basecf/curcf
		simuper <- matrix(0,1,Rsnpnum)
		simuper[1,qv] <- baseper
		temq <- qv-c(0,qv[-length(qv)])
		temb <- c(baseper,0)-c(0,baseper)
		seqtack <- which(temq!=1)

		for(ii in seqtack){
			simuper[,(qv[ii-1]+1):(qv[ii]-1)] <- temb[ii]/temq[ii]*c(1:(temq[ii]-1))+baseper[ii-1]
		}
		tind <- order(pm[,i])
		pm[tind,i] <- pm[tind,i]*simuper
		print(paste0(i," CGWAS Data Corrected"))
		if(i==1){
			sptind <- tind
			spsimuper <- simuper
		}
	}

	pm[pm>1] <- 1
	pm <- signif(pm,4)
	mincp <- apply(pm,1,min)
	write.table(as.data.frame(mincp),"Min.corrcp",row.names=F,col.names=F,quote=F)
	print(paste0("Derived CGWAS Minp"))
	sugghitind2 <- which(mincp<St)
	HJind2 <- which(mincp<Ht)

	spo <- as.matrix(fread("All.sortsp",header=F))
	system(paste0("rm All.sortsp"))
	
	baseseq <- c((1:length(Traitname))-1)/(length(Traitname)-1)
	for(i in 1:length(sptind)){
		spo[sptind[i],] <- spo[sptind[i],]*spsimuper[i]/(baseseq*(spsimuper[i]-1)+1)
	}
	spo[spo>1] <- 1
	spo <- signif(spo,4)
	fwrite(as.data.frame(spo),"All.corrsortsp",row.names=F,col.names=F,quote=F,sep=" ")
	print(paste0("corrGWAS Result Saved"))
	minsp <- apply(spo,1,min)
	write.table(as.data.frame(minsp),"Min.corrsp",row.names=F,col.names=F,quote=F)
	print(paste0("Derived GWAS Minp"))
	sugghitind <- which(as.numeric(minsp)<St)
	HJind <- which(minsp<Ht)

	sugghit3 <- union(sugghitind,sugghitind2)
	HJ3 <- union(HJind,HJind2)
	sugghit <- matrix(0,length(sugghit3)*length(Traitname),3)
	HJM <- matrix(0,length(HJ3),2)
	sugghit[,1] <- rep(sugghit3,each=length(Traitname))
	sugghit[,2] <- as.vector(t(pm[sugghit3,]))
	sugghit[,3] <- rep(c(1:length(Traitname)),length(sugghit3))
	HJM[,1] <- as.numeric(mincp)[HJ3]
	HJM[,2] <- as.numeric(minsp)[HJ3]
	HJpm <- pm[HJ3,]
	fwrite(as.data.frame(pm),paste0("All.corrcp"),row.names=F,col.names=F,quote=F,sep=" ")
	print(paste0("corrCGWAS Result Saved"))
	rm(pm)

	Sind <- as.data.frame(fread("SnpIndex",header=T))
	temres <- cbind(Sind[as.numeric(sugghit[,1]),],sugghit)
	temHJ <- cbind(Sind[HJ3,],HJM)
	temres <- temres[order(temres[,5]),]
	temres <- temres[order(temres[,2]),]
	temres <- temres[order(temres[,1]),]
	temHJ <- temHJ[order(temHJ[,2]),]
	temHJ <- temHJ[order(temHJ[,1]),]
	colnames(temres)[4:6] <- c("SNPid","CorrCP","CombNum")
	colnames(temHJ)[4:5] <- c("CP","BP")
	write.csv(temres,"CgwasRawSuggHits.csv",row.names=F,quote=F)
	write.table(as.data.table(temHJ),"HJ_man.txt",row.names=F,col.names=F,quote=F)
	print(paste0("CGWAS Suggestive Hits Saved"))

	sspo <- spo[sugghit3,]
	HJspo <- spo[HJ3,]
	rm(spo)
	for(i in 1:nrow(sspo)){
		for(ii in (length(Traitname)-1):1){
			if(sspo[i,ii]>sspo[i,ii+1]){
				sspo[i,ii] <- sspo[i,ii+1]
			}
		}
	}
	spsignum <- c()
	cpsignum <- c()
	for(i in 1:nrow(HJspo)){
		for(ii in (length(Traitname)-1):1){
			if(HJspo[i,ii]>HJspo[i,ii+1]){
				HJspo[i,ii] <- HJspo[i,ii+1]
			}
		}
		spsignum <- c(spsignum,sum(HJspo[i,]<=0.05))
		cpsignum <- c(cpsignum,which(HJpm[i,]==min(HJpm[i,]))[1])
	}
	spl <- as.matrix(fread("All.labsp",header=F))
	sspl <- spl[sugghit3,]
	HJspl <- spl[HJ3,]
	rm(spl)
	sugghit <- matrix(0,length(sugghit3)*length(Traitname),3)
	sugghit[,1] <- rep(sugghit3,each=length(Traitname))
	sugghit[,2] <- as.vector(t(sspo[,]))
	sugghit[,3] <- as.vector(t(sspl[,]))
	
	temres <- cbind(Sind[as.numeric(sugghit[,1]),],sugghit)
	temHJall <- cbind(Sind[HJ3,],cpsignum,spsignum,HJpm,HJspl,HJspo)
	temres <- temres[order(temres[,2]),]
	temres <- temres[order(temres[,1]),]
	temHJall <- temHJall[order(temHJall[,2]),]
	temHJall <- temHJall[order(temHJall[,1]),]
	temHJall <- temHJall[,-c(1:2)]
	colnames(temres)[4:6] <- c("SNPid","SP","Trait")
	write.csv(as.matrix(temres),"GwasRawSuggHits.csv",row.names=F,quote=F)
	write.table(as.data.table(temHJall),"HJ_bar.txt",row.names=F,col.names=F,quote=F)
	print(paste0("GWAS Suggestive Hits Saved"))
	print(paste0("Step5 Completed"))
}

step6 <- function(m_wid=3500,m_hei=3500,sing_col=c('chartreuse2','chartreuse4'),comb_col=c('darkgoldenrod2','darkgoldenrod4'),speeduppoints=T,q_wid=3500,q_hei=2400){
	setwd(paste0(CGPath,"Result/"))
	print(paste0("Read Data.."))
	Sind <- as.data.frame(fread("SnpIndex",header=T))
	singpm <- as.data.frame(fread("Min.corrsp",header=F))
	cpm <- as.data.frame(fread("Min.corrcp",header=F))
	cpfm <- cbind(Sind,-log10(singpm),-log10(cpm))

	if(speeduppoints){
		cpfm <- cpfm[-which((cpfm[,4]<1)&(cpfm[,5]<1)),]
		tem <- which((cpfm[,4]<2)&(cpfm[,5]<2))
		cpfm <- cpfm[-sample(tem,round(length(tem)*0.75)),]
		tem <- which((cpfm[,4]<3)&(cpfm[,5]<3))
		cpfm <- cpfm[-sample(tem,round(length(tem)*0.5)),]
		tem <- which((cpfm[,4]<4)&(cpfm[,5]<4))
		cpfm <- cpfm[-sample(tem,round(length(tem)*0.25)),]
		cpfm[which(cpfm[,4]<1),4] <- 0
		cpfm[which(cpfm[,5]<1),5] <- 0
	}

	print(paste0("Produce Manhattan Plots.."))
	jpeg("man.jpg",width=m_wid,height=m_hei,res=300)
	par(mar=c(2,5,2,2))
	manhattan(cpfm,cex.axis=1,spt.cex=1,cpt.cex=1,spt.col=sing_col,cpt.col=comb_col,pch=20)
	dev.off()
	print(paste0("Manhattan Plots Completed"))
	rm(cpfm)

	print(paste0("Read Data For QQplots.."))
	tsingm <- as.matrix(fread(paste0("All.sp"),header=F))
	tcombm <- as.matrix(fread(paste0("All.corrcp"),header=F))
	minqqm <- cbind(singpm,cpm)

	sgif <- as.numeric(qnorm(apply(tsingm/2,2,quantile,probs=0.5))/qnorm(0.25))
	cgif <- as.numeric(qnorm(apply(tcombm/2,2,quantile,probs=0.5))/qnorm(0.25))
	print(paste0("Lambda Calculated"))

	preCorrection()
	qv <- (qv-1)/(Rsnpnum-1)
	ee <- ppoints(nrow(tsingm))
	if(speeduppoints){
		ee <- quantile(ppoints(nrow(tsingm)),qv)
		singm <- apply(tsingm,2,quantile,probs=qv)
		rm(tsingm)
		print(paste0("QQplots: GWAS Data Extracted"))
		combm <- apply(tcombm,2,quantile,probs=qv)
		rm(tcombm)
		print(paste0("QQplots: CGWAS Data Extracted"))
		tminqqm <- cbind(quantile(minqqm[,1],qv),quantile(minqqm[,2],qv))
		minqqm <- tminqqm
	} else{
		singm <- apply(tsingm,2,sort)
		rm(tsingm)
		minqqm[,1] <- sort(minqqm[,1])
		print(paste0("QQplots: GWAS Data Extracted"))
		combm <- apply(tcombm,2,sort)
		rm(tcombm)
		minqqm[,2] <- sort(minqqm[,2])
		print(paste0("QQplots: CGWAS Data Extracted"))
	}
	singm <- -log10(singm)
	combm <- -log10(combm)
	minqqm <- -log10(minqqm)
	ee <- -log10(ee)

	print(paste0("Produce QQ Plots.."))
	jpeg("qq.jpg",width=q_wid,height=q_hei,res=300)
	par(mfrow=c(2,3))
	par(mar=c(5,5,2,2))
	qq(singm,combm,minqqm,ee,sgif,cgif,c(sing_col[1],comb_col[1]))
	dev.off()
	print(paste0("QQ Plots Completed"))
	print(paste0("Step6 Completed"))
}

step7 <- function(){
	setwd(paste0(CGPath,"Result/"))
	basegm <- read.csv("GwasRawSuggHits.csv",header=T,stringsAsFactors=F)
	basecm <- read.csv("CgwasRawSuggHits.csv",header=T,stringsAsFactors=F)
	print(paste0("Read Data Completed"))
	SNPn <- unique(basegm$SNP)
	tem <- c()
	for(i in 1:length(SNPn)){
		temgm <- basegm[(((i-1)*length(Traitname)+1):(i*length(Traitname))),]
		temcm <- basecm[(((i-1)*length(Traitname)+1):(i*length(Traitname))),]
		fdrsp <- as.numeric(temgm[,5])
		sgt <- 0
		if(fdrsp[1]<=St){
			sgt <- 1
			if(fdrsp[1]<=Gt){
				sgt <- 2
			}
		}
		fdrcp <- as.numeric(temcm[,5])
		cgt <- 0
		if(fdrcp[1]<=St){
			cgt <- 1
			if(fdrcp[1]<=Gt){
				cgt <- 2
			}
		}
		signum <- sum(fdrsp<=0.05)
		temv <- c(temgm[1,1:5],temcm[1,5],temgm[1,6],sgt,cgt,signum,temcm[1,6],c(temgm[,6],fdrsp,fdrcp[order(temcm[,6])])[rep(seq(1,3*length(Traitname),length(Traitname)),length(Traitname))+rep(0:(length(Traitname)-1),each=3)])
		tem <- rbind(tem,temv)
	}
	print(paste0("Format Data Completed"))

	locim <- matrix(unlist(tem[,1:2]),ncol=2)
	locic <- c()
	startchr <- locim[1,1]
	startbp <- locim[1,2]
	startloci <- 1
	locinum <- 1
	for(i in 1:nrow(locim)){
		if(locim[i,1]==startchr){
			if((locim[i,2]-startbp)<500000){
				locic[i] <- paste(startchr,"_",startloci,sep="")
				startbp <- locim[i,2]
			} else{
				startloci <- startloci + 1
				locinum <- locinum + 1
				locic[i] <- paste(startchr,"_",startloci,sep="")
				startbp <- locim[i,2]
			}
		} else{
			startchr <- locim[i,1]
			startloci <- 1
			locinum <- locinum + 1
			locic[i] <- paste(startchr,"_",startloci,sep="")
			startbp <- locim[i,2]
		}
	}
	print(paste0("Loci Zoning Completed"))

	tem <- cbind(tem[,1:4],locic,tem[,5:ncol(tem)])
	colnames(tem) <- c(colnames(tem)[1:4],"Loci","MinCorrSp","MinCorrCp","MinSpTrait","SpSigType","CpSigType","SpSigNum","MinCpNum",paste0(c("Rank","CorrSp","CorrCp"),rep(1:length(Traitname),each=3)))
	write.csv(tem,"AllHits.csv",row.names=F,quote=F)

	topsnpi <- c()
	Sp_or_Cp <- c()
	for(i in unique(locic)){
		gt <- intersect(which(locic==i),as.numeric(which(unlist(tem[,6])==min(as.numeric(tem[which(locic==i),6])))))
		ct <- intersect(which(locic==i),as.numeric(which(unlist(tem[,7])==min(as.numeric(tem[which(locic==i),7])))))
		temv <- union(ct,gt)
		indv <- order(temv)
		topsnpi <- c(topsnpi,temv[indv])
		gv <- rep(0,length(temv))
		for(ii in 1:length(gt)){
			gv[which(temv==gt[ii])] <- 1
		}
		cv <- rep(0,length(temv))
		for(ii in 1:length(ct)){
			cv[which(temv==ct[ii])] <- 2
		}
		mv <- c(gv+cv)[indv]
		mv[mv==1] <- "S"
		mv[mv==2] <- "C"
		mv[mv==3] <- "SC"
		Sp_or_Cp <- c(Sp_or_Cp,mv)
	}
	print(paste0("Pick Top Hits Completed"))
	write.csv(cbind(tem[topsnpi,1:5],Sp_or_Cp,tem[topsnpi,6:ncol(tem)]),"TopSNP.csv",row.names=F,quote=F)
	print(paste0("Step7 Completed"))
}